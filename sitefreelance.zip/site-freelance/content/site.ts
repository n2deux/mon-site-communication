/**
 * Point d'entrée unique de l'identité du site.
 * Tout ce qui est entre crochets [ ... ] est un PLACEHOLDER à remplacer.
 * Les liens dont l'URL est encore un placeholder ne sont pas cliquables
 * (aucune fausse adresse n'est publiée).
 */

export const site = {
  /** Nom de marque affiché dans le header, le footer et les métadonnées */
  brand: "[NOM / MARQUE]",
  /** Version courte pour le logo (2 à 12 caractères) */
  brandShort: "[NOM]",
  /** Votre identité civile, utilisée dans « À propos » et les mentions légales */
  fullName: "[PRÉNOM NOM]",
  role: "Communication digitale · Contenu · Social media · Acquisition",
  city: "Rennes",
  region: "Bretagne",
  country: "France",

  email: "[EMAIL]",
  phone: "[TÉLÉPHONE]",

  socials: {
    instagram: { label: "[INSTAGRAM]", url: "[URL_INSTAGRAM]" },
    linkedin: { label: "[LINKEDIN]", url: "[URL_LINKEDIN]" },
  },

  /** Statut juridique — à compléter dès l'immatriculation */
  legal: {
    status: "[STATUT JURIDIQUE — ex. micro-entreprise]",
    siret: "[SIRET]",
    address: "[ADRESSE]",
    hostName: "[HÉBERGEUR]",
    hostAddress: "[ADRESSE HÉBERGEUR]",
  },
} as const;

/** Détecte un placeholder non encore renseigné. */
export function isPlaceholder(value: string): boolean {
  return value.trim().startsWith("[") && value.trim().endsWith("]");
}

export const siteUrl = (
  process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"
).replace(/\/$/, "");
